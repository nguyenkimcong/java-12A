package vn.techmaster.firstweb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstwebApplicationTests {

	@Test
	void contextLoads() {
	}

}
