package vn.techmaster.firstweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstwebApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstwebApplication.class, args);
	}

}
